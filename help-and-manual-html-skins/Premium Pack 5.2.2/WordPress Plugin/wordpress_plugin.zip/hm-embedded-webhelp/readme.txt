=== Embedded WebHelp for WordPress Version 2.1 ===
Tags: webhelp, embedded, field-level
Requires at least: 5.0.0
Tested up to: 5.6.1
Stable tag: 5.6

Embedded Help+Manual WebHelp for WordPress. Requires H+M Premium Pack 4.1 or higher with V3 or V4 Responsive skins.

== Description ==

This plugin automates integration of embedded Help+Manual WebHelp in self-hosted WordPress sites. It is not supported on sites hosted by WordPress.com. It includes support for field-level topics and popups displayed with hyperlinks in your WordPress posts and pages. This only works with WebHelp generated using the V3 and V4 Responsive skins in the Help+Manual Premium Pack 4.1 or higher. It will not work with earlier skin versions and will display an error warning for WebHelp created with older skins. 

++ Support for multiple embedded WebHelp collections and collections on different servers ++

Version 2.0 introduced support for multiple WebHelp collections on a single WordPress site. If you only have one collection you just need to set its default URL and default filename in the main plugin settings. That URL will then be used automatically in all widget instances. If you have multiple WebHelp collections you can set a different URL and filename in each widget instance. 

Version 2.1 adds support for WebHelp collections that are not installed on the same server as your WordPress site, also including multiple collections. To do this you must configure the list of domains involved in both the plugin settings and your WebHelp. See the Premium Pack documentation for full details. 

++ Support for topic links to multiple WebHelp collections and collections on different servers ++

Version 2.1 introduces support for links to topics in embedded help in multiple WebHelp collections, including collections that are not on the same server as your WordPress site. Here too, this requires special configuration. See the Premium Pack documentation for full details. 

++ Support for field-level topics and popups from multiple WebHelp collections and collections on different servers ++

Version 2.1 also introduces support for field-level topics and popups from multiple WebHelp collections, which do not need to be on the same server as your WordPress installation. Here too, this requires special configuration. See the Premium Pack documentation for full details. 

== Installation ==

Before you install the plugin you need to publish your WebHelp using a V3 or V4 Responsive skin from Help+Manual Premium Pack 4.1 or higher. You must then upload your WebHelp to your web server, which can be the same server where your WordPress is hosted or a different server. You must NOT save your WebHelp in the same server folder as your WordPress installation. If the server is not the same as the one where your WordPress is installed you must configure all the domains involved in your plugin and WebHelp settings. See the Premium Pack documentation for full details. 

1. Upload the entire *hm-embedded-webhelp* folder to your WordPress plugins folder.
2. Access the Plugins section in your WordPress dashboard and activate the Embedded WebHelp for WordPress plugin.
3. Click on the Settings link below the plugin name to access the Settings page. Add the absolute path to your default WebHelp collection, including the "http://" or "https://" prefix. Also add the default file with which your WebHelp collection should start (usually index.html).
4. Select the Appearance > Widgets section in the dashboard and drag the WebHelp Widget to the position where you want to display it. Enter the initial text for the widget button as the widget title (e.g. "Show Help").
5. By default the widget will access the default WebHelp collection. If you only want to access one WebHelp collection leave the settings here unchanged. 
6. If you want to access an additional WebHelp collection you can do this by adding an additional widget with the path and topic from that collection. 

You can adjust the position of the embedded help with the other settings, and whether you want support for field-level topics and popups. See the Premium Pack documentation for full instructions, also for how to write the links for field-level help, which also supports multiple WebHelp collections and collections on different servers. 
