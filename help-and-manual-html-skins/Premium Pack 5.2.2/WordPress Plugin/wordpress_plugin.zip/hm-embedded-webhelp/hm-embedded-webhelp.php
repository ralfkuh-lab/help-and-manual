<?php
/*
Plugin Name: Embedded WebHelp for Wordpress
Plugin URI: http://www.helpandmanual.com/
Description: Embedded Help+Manual WebHelp for Premium Pack V3 & V4 Responsive Skins
Version: 2.1
Author: Tim Green
Author URI: http://www.helpandmanual.com/
Text Domain: webhelp-plugin
Domain Path: /languages
*/
if(!class_exists('HM_Embedded_WebHelp'))
{
	
    class HM_Embedded_WebHelp extends WP_Widget
    {
		var $defaults; // default values
		var $customs; // user-defined values
		
        /**
         * Construct the plugin object
         */
        public function __construct()
        {
			// Set settings as constants for quicker access
			define("WH_PATH", (trailingslashit(get_option('webhelp_path'))));
			define("WH_DOMAINS", (get_option('webhelp_domains')));
			define("WH_TOPIC", (get_option("webhelp_topic")));
			define("WH_FONT", (get_option("webhelp_font")));
			define("WH_STATE", (get_option("webhelp_state","hidden") == "hidden" ? "none" : "block"));
			define("WH_OPENTOPIC", (get_option("webhelp_opentopic","Click here to open this topic in a full help window")));
			define("WH_CALLBACK", (get_option("webhelp_callback")));
			define("WH_ACTIVATE", (get_option("webhelp_active","both")));
			define("WH_POSITION", (get_option("webhelp_position","left")));
			define("WH_LEFT", (get_option("webhelp_left","")));
			define("WH_TOP", (get_option("webhelp_top","")));
			define("WH_RIGHT", (get_option("webhelp_right","")));
			define("WH_BOTTOM", (get_option("webhelp_bottom","")));
			define("WH_HEIGHT", (get_option("webhelp_height","")));
			define("WH_WIDTH", (get_option("webhelp_width","")));
			define("WH_SHOWTEXT", (get_option("webhelp_show","")));
			define("WH_HIDETEXT", (get_option("webhelp_hide","")));
			define("WH_REQUIREVERSION", 3.2);
			define("WH_PLUGIN_TITLE",'Embedded WebHelp Plugin');
			
            // register actions
			add_action('admin_init', array(&$this, 'admin_init'));
			add_action('admin_menu', array(&$this, 'add_menu'));
			add_action( 'wp_enqueue_scripts', array(&$this, 'enqueued_webhelp_assets' ));
			add_action( 'wp_footer', array(&$this, 'webhelp_footer'), 100);
			
        } // END public function __construct
		
		
		/**
		 * hook into WP's admin_init action hook
		 */
		public function admin_init()
		{
			// Set up the settings for this plugin
			$this->init_settings();

			// Possibly do additional admin_init tasks

		} // END public static function activate
		
		/**
		 * Initialize some custom settings
		 */     
		public function init_settings()
		{
			// register the settings for this plugin
			register_setting('hm_webhelp-group', 'webhelp_path');
			register_setting('hm_webhelp-group', 'webhelp_domains');
			register_setting('hm_webhelp-group', 'webhelp_topic');
			register_setting('hm_webhelp-group', 'webhelp_state');
			register_setting('hm_webhelp-group', 'webhelp_opentopic');
			register_setting('hm_webhelp-group', 'webhelp_callback');
			register_setting('hm_webhelp-group', 'webhelp_font');
			register_setting('hm_webhelp-group', 'webhelp_active');
			register_setting('hm_webhelp-group', 'webhelp_position');
			register_setting('hm_webhelp-group', 'webhelp_show');
			register_setting('hm_webhelp-group', 'webhelp_hide');
			register_setting('hm_webhelp-group', 'webhelp_left');
			register_setting('hm_webhelp-group', 'webhelp_top');
			register_setting('hm_webhelp-group', 'webhelp_bottom');
			register_setting('hm_webhelp-group', 'webhelp_right');
			register_setting('hm_webhelp-group', 'webhelp_height');
			register_setting('hm_webhelp-group', 'webhelp_width');
			
		} // END public function init_custom_settings()
		
		/**
		 * add a menu
		 */     
		public function add_menu()
		{
			add_options_page('HM Embedded WebHelp Settings', 'HM Embedded WebHelp', 'manage_options', 'wp_embedded_webhelp', array(&$this, 'plugin_settings_page'));
		} // END public function add_menu()

		/**
		 * Menu Callback
		 */     
		public function plugin_settings_page()
		{
			if(!current_user_can('manage_options'))
			{
				wp_die(__('You do not have sufficient permissions to access this page.'));
			}

			// Render the settings template
			include(sprintf("%s/templates/settings.php", dirname(__FILE__)));
		} // END public function plugin_settings_page()
		
		
		public function enqueued_webhelp_assets() {
			
			if ( ! wp_script_is( 'jquery', 'enqueued' )) {
				//Enqueue
				wp_enqueue_script( 'jquery' );
			}

			wp_enqueue_script( 'webhelp-xmessage-script', plugin_dir_url( __FILE__ ) . 'scripts/xmessage.js', array( 'jquery' ), (string)WH_REQUIREVERSION , false );
			
			$WhPathAndDomains = array (
				'hmwebhelp_default_path' => WH_PATH,
				'hmwebhelp_default_topic' => WH_TOPIC,
				'hmwebhelp_allowed_domains' => WH_DOMAINS,
				'plugin_dir_path' => plugin_dir_url( __FILE__ )
			);
			wp_localize_script( 'webhelp-xmessage-script', 'php_vars', $WhPathAndDomains );
			
			if (WH_ACTIVATE != 'popups') {

			wp_enqueue_script( 'webhelp-embed-script', plugin_dir_url( __FILE__ ) . 'scripts/hmEmbedHelp.js', array( 'jquery' ), (string)WH_REQUIREVERSION , false );
			wp_enqueue_style( 'webhelp-embed-styles', plugin_dir_url( __FILE__ ) . 'css/wordpress_embed.css');

				$custom_css = "div#helpwrapper{ "
							. "left: " . WH_LEFT . "; "
							. "right: " . WH_RIGHT . "; "
							. "top: " . WH_TOP . "; "
							. "bottom: " . WH_BOTTOM . "; "
							. "height: " . WH_HEIGHT . "; "
							. "width: " . WH_WIDTH . ";"
							. "} ";
				
			wp_add_inline_style('webhelp-embed-styles', $custom_css);
			
			$WhPathAndDomains = array (
				'hmwebhelp_default_state' => WH_STATE,
				'hmwebhelp_default_path' => WH_PATH,
				'hmwebhelp_default_topic' => WH_TOPIC,
				'hmwebhelp_allowed_domains' => WH_DOMAINS,
				'plugin_dir_path' => plugin_dir_url( __FILE__ ),
				'hmwebhelp_showtext' => WH_SHOWTEXT,
				'hmwebhelp_hidetext' => WH_HIDETEXT,
				'hmwebhelp_callback' => WH_CALLBACK
			);
			wp_localize_script( 'webhelp-embed-script', 'php_vars', $WhPathAndDomains );
			}


			if (WH_ACTIVATE != 'webhelp') {

			wp_enqueue_style( 'webhelp-popups-styles', plugin_dir_url( __FILE__ ) . 'css/hm_popup.css');

				$custom_popup_css = "div.hmpopup, p.hmpopup {"
					. "font-family: " . WH_FONT . ";"
					. "}";

			wp_add_inline_style('webhelp-popups-styles', $custom_popup_css);

			wp_enqueue_script( 'webhelp-popups-script',  plugin_dir_url( __FILE__ ) . 'scripts/hmEmbeddedPopups.js', array( 'jquery' ), (string)WH_REQUIREVERSION, false );
			}
			
			$PopPathAndDomains = array (
				'hmwebhelp_default_state' => WH_STATE,
				'hmwebhelp_default_path' => WH_PATH,
				'hmwebhelp_default_topic' => WH_TOPIC,
				'hmwebhelp_allowed_domains' => WH_DOMAINS,
				'plugin_dir_path' => plugin_dir_url( __FILE__ ),
				'hmwebhelp_showtext' => WH_SHOWTEXT,
				'hmwebhelp_hidetext' => WH_HIDETEXT,
				'hmwebhelp_opentopic' => WH_OPENTOPIC
			);
			wp_localize_script( 'webhelp-popups-script', 'php_vars', $PopPathAndDomains );

		}
		
		public function webhelp_footer() {
		if (WH_ACTIVATE != 'popups') {
			echo '<div id="helpwrapper"><div id="helpcloser" title="' . WH_HIDETEXT . '" onclick=""></div></div>
				
				<script>
				if (typeof hmDevice.ppversion == "undefined" || hmDevice.ppversion < ' . WH_REQUIREVERSION . ')
					alert("';
			_e('EMBEDDED WEBHELP PLUGIN ERROR!\r\nYour Premium Pack skin is out of date. This plugin requires Help+Manual Premium Pack version ' . WH_REQUIREVERSION . ' or higher.','webhelp-plugin');
			echo ' or higher.");
				</script>';
		} else {
			echo '<script>
				if (typeof hmXPopup.hmDevice.ppversion == "undefined" || hmXPopup.hmDevice.ppversion < ' . WH_REQUIREVERSION . ')
					alert("';
			_e('EMBEDDED WEBHELP PLUGIN ERROR!\r\nYour Premium Pack skin is out of date. This plugin requires Help+Manual Premium Pack version ' . WH_REQUIREVERSION . ' or higher.','webhelp-plugin');
			echo ' or higher.");
				</script>';
		}
		}
		
        public static function activate()
        {
            // Do nothing
        }
    

        public static function deactivate()
        {
            // Do nothing
        } 
    } 
} // END if(!class_exists('HM_Embedded_WebHelp'))
	
if(class_exists('HM_Embedded_WebHelp'))
{
    // Installation and uninstallation hooks
    register_activation_hook(__FILE__, array('HM_Embedded_WebHelp', 'activate'));
    register_deactivation_hook(__FILE__, array('HM_Embedded_WebHelp', 'deactivate'));

    // instantiate the plugin class
    $wp_embedded_webhelp = new HM_Embedded_WebHelp();
	
	// Add a link to the settings page onto the plugin page
	if(isset($wp_embedded_webhelp))
	{
		// Add the settings link to the plugins page
		function plugin_settings_link($links)
		{ 
			$settings_link = '<a href="options-general.php?page=wp_embedded_webhelp">Settings</a>'; 
			array_unshift($links, $settings_link); 
			return $links; 
		}

		$plugin = plugin_basename(__FILE__); 
		add_filter("plugin_action_links_$plugin", 'plugin_settings_link');
	}		
}

// Control widget for displaying and hiding embedded WebHelp
class webhelp_widget extends WP_Widget {

function __construct() {

	$widget_options = array(
		'classname' => 'webhelp_widget',
		'description' => 'Embedded WebHelp Widget',
		'webhelp_url' => WH_PATH,
		'webhelp_topic' => WH_TOPIC,
		'webhelp_callback' => WH_CALLBACK
	);
	
	parent::__construct(
	// Base ID 
	'webhelp_widget', 'WebHelp Widget', $widget_options
	// Widget name and description
	//__('WebHelp Widget', 'webhelp-plugin'), 
	//array( 'description' => __( 'Control widget for embedded WebHelp created with a Help+Manual V3 Responsive Premium Pack skin', 'webhelp-plugin' ), ) 
	);
}

// Insert the button
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
// Theme's before and after functions
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

// Control button
	_e( '<button class="hmHelpToggle" type="button" onclick="HMshowHelpInstance(\''. $instance[ 'webhelp_url' ] .'\',\''. $instance[ 'webhelp_topic' ] .'\'' . (( ! empty( $instance['webhelp_callback']) ) ? (', ' . $instance['webhelp_callback']) : '' ) . ')">' . get_option('webhelp_show') . '</button>', 'webhelp-plugin' );
echo $args['after_widget'];
}
		
// Widget Backend 
public function form( $instance ) {

if ( ! empty( $instance[ 'title' ] ) ) {
	$title = $instance[ 'title' ];
	}
	else {
	$title = WH_PLUGIN_TITLE;
	//$title = __( $GLOBALS['webhelp_widget_title'], 'webhelp-plugin' );
	}

	//$webhelp_url = ( isset( $instance[ 'webhelp_url' ] ) ) ? $instance[ 'webhelp_url' ] : $this->defaults[ 'webhelp_url' ];
	$webhelp_url = ( isset($instance[ 'webhelp_url' ] ) && ! empty( $instance[ 'webhelp_url' ] ) ) ? $instance[ 'webhelp_url' ] : WH_PATH;
	$webhelp_topic = ( isset($instance[ 'webhelp_topic' ] ) && ! empty( $instance[ 'webhelp_topic' ] ) ) ? $instance[ 'webhelp_topic' ] : WH_TOPIC;
	$webhelp_callback =  ( isset($instance[ 'webhelp_callback' ] ) ) ? $instance[ 'webhelp_callback' ] : WH_CALLBACK;
	//$webhelp_callback =  ( isset($instance[ 'webhelp_callback' ] ) && ! empty( $instance[ 'webhelp_callback' ] ) ) ? $instance[ 'webhelp_callback' ] : WH_CALLBACK;
	
	//( isset($instance[ 'webhelp_callback' ] ) && ! empty( $instance[ 'webhelp_callback' ] ) ) ? $instance[ 'webhelp_callback' ] : ( ( ( ! empty($instance[ 'webhelp_url' ] ) ) && ( $instance[ 'webhelp_url' ] == WH_PATH ) )  ? WH_CALLBACK : "") ;

// Widget admin form
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'webhelp-plugin' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php esc_attr_e( $title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'webhelp_url' ); ?>">WebHelp URL:</label>
<input class="widefat" id="<?php echo $this->get_field_id( 'webhelp_url' ); ?>" name="<?php echo $this->get_field_name( 'webhelp_url' ); ?>" type="text" value="<?php trailingslashit(esc_attr_e( $webhelp_url ));?>">
</p>

<p>
<label for="<?php echo $this->get_field_id( 'webhelp_topic' ); ?>">WebHelp Topic:</label>
<input class="widefat" id="<?php echo $this->get_field_id( 'webhelp_topic' ); ?>" name="<?php echo $this->get_field_name( 'webhelp_topic' ); ?>" type="text" value="<?php esc_attr_e( $webhelp_topic );?>">
</p>

<p>
<label for="<?php echo $this->get_field_id( 'webhelp_callback' ); ?>">WebHelp Callback:</label>
<input class="widefat" id="<?php echo $this->get_field_id( 'webhelp_callback' ); ?>" name="<?php echo $this->get_field_name( 'webhelp_callback' ); ?>" type="text" value="<?php esc_attr_e( $webhelp_callback );?>">
</p>

<?php 
}
	
// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['webhelp_url'] = ( ! empty( $new_instance['webhelp_url'] ) ) ? esc_url_raw(trailingslashit(strip_tags( $new_instance['webhelp_url'] )),array('http','https')) : '';
$instance['webhelp_topic'] = ( ! empty( $new_instance['webhelp_topic'] ) ) ? sanitize_file_name(strip_tags( $new_instance['webhelp_topic'] )) : '';
$instance['webhelp_callback'] = ( ! empty( $new_instance['webhelp_callback'] ) ) ? sanitize_file_name(strip_tags( $new_instance['webhelp_callback'] )) : '';
return $instance;
}
} // Class webhelp_widget ends here

// Register and load the widget
function webhelp_load_widget() {
	register_widget( 'webhelp_widget' );
}
add_action( 'widgets_init', 'webhelp_load_widget' );