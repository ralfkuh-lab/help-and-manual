<div class="wrap">
    <h2><?php _e('Embedded WebHelp Plugin Settings','webhelp-plugin>') ?></h2>
    <form method="post" action="options.php" id="webhelp_settings_form"> 
        <?php settings_fields('hm_webhelp-group'); ?>
        <?php do_settings_sections('hm_webhelp-group', 'wp_embedded_webhelp'); ?>
		<?php 
			  $webhelp_current_active = get_option('webhelp_active','webhelp');
			  $webhelp_current_font = get_option('webhelp_font','Arial, Helvetica');
			  $webhelp_current_state = get_option('webhelp_state','hidden');
			  $webhelp_current_position = get_option('webhelp_position','left');
			  $webhelp_current_show = get_option('webhelp_show','Show Embedded Help');
			  $webhelp_current_hide = get_option('webhelp_hide','Hide Embedded Help');

			  $webhelp_current_opentopic = get_option('webhelp_opentopic','Click here to open this topic in a full help window');
			  
			  $webhelp_current_left = get_option('webhelp_left','');
			  $webhelp_current_top = get_option('webhelp_top','');
			  $webhelp_current_right = get_option('webhelp_right','');
			  $webhelp_current_bottom = get_option('webhelp_bottom','');
			  $webhelp_current_height = get_option('webhelp_height','');
			  $webhelp_current_width = get_option('webhelp_width','') ;
			  
			  switch ($webhelp_current_position) {
				  case 'left':
				  if ($webhelp_current_left == '' || $webhelp_current_left == 'auto') {
				  update_option('webhelp_left','20px');
				  $webhelp_current_left = '20px';
				  }
				  if ($webhelp_current_right != 'auto'){
				  update_option('webhelp_right','auto');
				  $webhelp_current_right = 'auto';
				  }
				  if ($webhelp_current_bottom == 'auto' || $webhelp_current_bottom == ''){
				  update_option('webhelp_bottom','20px');
				  $webhelp_current_bottom = '20px';
				  }
				  if ($webhelp_current_top == 'auto' || $webhelp_current_top == ''){
				  update_option('webhelp_top','53px');
				  $webhelp_current_top = '53px';
				  }
				 if ($webhelp_current_width == 'auto' || $webhelp_current_width == ''){
				  update_option('webhelp_width','50%');
				  $webhelp_current_width = '50%';
				  }
				  if ($webhelp_current_height != 'auto'){
				  update_option('webhelp_height','auto');
				  $webhelp_current_height = 'auto';
				  }  
				  break;
				  case 'right':
				  if ($webhelp_current_left != 'auto') {
				  update_option('webhelp_left','auto');
				  $webhelp_current_left = 'auto';
				  }
				  if ($webhelp_current_right == 'auto' || $webhelp_current_right == ''){
				  update_option('webhelp_right','20px');
				  $webhelp_current_right = '20px';
				  }
				  if ($webhelp_current_bottom == 'auto' || $webhelp_current_bottom == ''){
				  update_option('webhelp_bottom','20px');
				  $webhelp_current_bottom = '20px';
				  }
				  if ($webhelp_current_top == 'auto' || $webhelp_current_top == ''){
				  update_option('webhelp_top','53px');
				  $webhelp_current_top = '53px';
				  }
				 if ($webhelp_current_width == 'auto' || $webhelp_current_width == ''){
				  update_option('webhelp_width','50%');
				  $webhelp_current_width = '50%';
				  }
				  if ($webhelp_current_height != 'auto'){
				  update_option('webhelp_height','auto');
				  $webhelp_current_height = 'auto';
				  }  
				  break;
				  case 'bottom':
				  if ($webhelp_current_left == 'auto' || $webhelp_current_left == '') {
				  update_option('webhelp_left','20px');
				  $webhelp_current_left = '20px';
				  }
				  if ($webhelp_current_right == 'auto' || $webhelp_current_right == ''){
				  update_option('webhelp_right','20px');
				  $webhelp_current_right = '20px';
				  }
				  if ($webhelp_current_bottom == 'auto' || $webhelp_current_bottom == ''){
				  update_option('webhelp_bottom','20px');
				  $webhelp_current_bottom = '20px';
				  }
				  if ($webhelp_current_top != 'auto'){
				  update_option('webhelp_top','auto');
				  $webhelp_current_top = 'auto';
				  }
				 if ($webhelp_current_width != 'auto'){
				  update_option('webhelp_width','auto');
				  $webhelp_current_width = 'auto';
				  }
				  if ($webhelp_current_height == 'auto' || $webhelp_current_height == ''){
				  update_option('webhelp_height','50%');
				  $webhelp_current_height = '50%';
				  } 
				  break;
			  }
			  
			  
			  echo "<style>
			  table.hmsettings td {
				padding: 3px 3px 3px 0!important;
				}
			  table.hmsettings th {
				padding: 3px 0 3px 3px !important;
				}
			  </style>"
		?>

        <table class="form-table hmsettings">
			<tr valign="top">
                <th scope="row"><label for="webhelp_active"><?php _e('Activate','webhelp-plugin>') ?>:</label></th>
                <td><select name="webhelp_active" id="webhelp_active_input">
				<option value="webhelp" <?php if ($webhelp_current_active == "webhelp") echo "selected"; ?>><?php _e('Embedded WebHelp','webhelp-plugin>') ?></option>
				<option value="popups" <?php if ($webhelp_current_active == "popups") echo "selected"; ?>><?php _e('Field-level Popups and Topics','webhelp-plugin>') ?></option>
				<option value="both" <?php if ($webhelp_current_active == "both") echo "selected"; ?>><?php _e('WebHelp + Popups/Topics','webhelp-plugin>') ?></option>
			  </select></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="webhelp_path"><?php _e('Path to WebHelp','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" style="width: 50%;" name="webhelp_path" id="webhelp_path_input" value="<?php echo esc_url_raw(trailingslashit(get_option('webhelp_path')), array('http','https')); ?>" /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_domains"><?php _e('Allowed Domains','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_domains" id="webhelp_domains_input" style="width:50%;" value="<?php echo get_option('webhelp_domains'); ?>" /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_state"><?php _e('Default WebHelp State','webhelp-plugin>') ?>:</label></th>
                <td><select name="webhelp_state" id="webhelp_state_input" <?php if ($webhelp_current_active == 'popups') echo 'disabled="disabled"' ?>>
				<option value="hidden" <?php if ($webhelp_current_state == "hidden") echo "selected"; ?>><?php _e('Hidden','webhelp-plugin>') ?></option>
				<option value="visible" <?php if ($webhelp_current_state!= "hidden") echo "selected"; ?>><?php _e('Visible','webhelp-plugin>') ?></option>
			  </select></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="webhelp_topic"><?php _e('Default WebHelp Topic','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" style="width: 50%;" name="webhelp_topic" id="webhelp_topic_input" value="<?php echo sanitize_file_name(get_option('webhelp_topic','index.html')); ?>" 
				<?php if ($webhelp_current_active == 'popups') echo 'readonly="readonly"' ?>/></td>
			</tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_callback"><?php _e('WebHelp Callback Function','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" style="width: 50%;" name="webhelp_callback" id="webhelp_callback_input" value="<?php echo sanitize_file_name(get_option('webhelp_callback','')); ?>" 
				<?php if ($webhelp_current_active == 'popups') echo 'readonly="readonly"' ?>/></td>
			</tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_font"><?php _e('Window Header Font','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_font" style="width: 50%;" id="webhelp_font_input" value="<?php echo get_option('webhelp_font','\'Trebuchet MS\', Helvetica, Arial, sans-serif'); ?>" 
				<?php if ($webhelp_current_active == 'popups') echo 'readonly="readonly"' ?>/></td>
            </tr>
			
			
			<tr valign="top">
                <th scope="row"><label for="webhelp_show"><?php _e('Show Help Button Text','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_show" style="width: 50%;" id="webhelp_show_input" value="<?php echo $webhelp_current_show; ?>" 
				<?php if ($webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_hide"><?php _e('Hide Help Button Text','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_hide" style="width: 50%;" id="webhelp_hide_input" value="<?php echo $webhelp_current_hide; ?>" 
				<?php if ($webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
		<tr valign="top">
                <th scope="row"><label for="webhelp_opentopic"><?php _e('Field-level Topic Link Text','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" style="width: 50%;" name="webhelp_opentopic" id="webhelp_opentopic_input" value="<?php echo $webhelp_current_opentopic; ?>" /></td>
            </tr>
			
			<tr valign="top">
                <th scope="row"><label for="webhelp_position"><?php _e('WebHelp Position','webhelp-plugin>') ?>:</label></th>
                <td><select name="webhelp_position" id="webhelp_position_input" <?php if ($webhelp_current_active == 'popups') echo 'disabled="disabled"' ?>>
				<option value="left" <?php if ($webhelp_current_position == "left") echo "selected"; ?>><?php _e('Left','webhelp-plugin>') ?></option>
				<option value="bottom" <?php if ($webhelp_current_position == "bottom") echo "selected"; ?>><?php _e('Bottom','webhelp-plugin>') ?></option>
				<option value="right" <?php if ($webhelp_current_position == "right") echo "selected"; ?>><?php _e('Right','webhelp-plugin>') ?></option>
			  </select></td>
            </tr>

			 <tr valign="top">
                <th scope="row"><label for="webhelp_height"><?php _e('WebHelp Height','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_height" id="webhelp_height_input" value="<?php echo $webhelp_current_height; ?>" 
				<?php if ($webhelp_current_height == 'auto' || $webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_width"><?php _e('WebHelp Width','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_width" id="webhelp_width_input" value="<?php echo $webhelp_current_width; ?>"
				<?php if ($webhelp_current_width == 'auto' || $webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_left"><?php _e('Left Offset','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_left" id="webhelp_left_input" value="<?php echo $webhelp_current_left; ?>" 
				<?php if ($webhelp_current_left == 'auto' || $webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_top"><?php _e('Top Offset','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_top" id="webhelp_top_input" value="<?php echo $webhelp_current_top; ?>"
				<?php if ($webhelp_current_top == 'auto' || $webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_right"><?php _e('Right Offset','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_right" id="webhelp_right_input" value="<?php echo $webhelp_current_right; ?>"  
				<?php if ($webhelp_current_right == 'auto' || $webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
			<tr valign="top">
                <th scope="row"><label for="webhelp_bottom"><?php _e('Bottom Offset','webhelp-plugin>') ?>:</label></th>
                <td><input type="text" name="webhelp_bottom" id="webhelp_bottom_input" value="<?php echo $webhelp_current_bottom; ?>" 
				<?php if ($webhelp_current_bottom == 'auto' || $webhelp_current_active == 'popups') echo 'readonly="readonly"' ?> /></td>
            </tr>
			<tr valign="top">
				<td colspan="2" valign="top"><?php submit_button();?></td>
			<tr valign="top">
				<td colspan="2" valign="top">
				<h2 style="padding-top: 0; margin-top: 0;"><?php _e('Instructions','webhelp-plugin>') ?>:</h2>
				<p style="font-weight: 600; font-size: 1rem"><?php _e('Activate','webhelp-plugin>') ?></p>
				<p><?php _e('Choose which embedded WebHelp features you want to support here. If you are only embedding WebHelp then choose <strong>Embedded WebHelp</strong>. If you are only using field-level popups and topics choose <strong>Field-level Popups and Topics</strong>. Or choose <strong>WebHelp + Popups/Topics</strong> for both.','webhelp-plugin>') ?></p>
				<p style="font-weight: 600; font-size: 1rem; margin-top: 1rem;"><?php _e('Path to WebHelp','webhelp-plugin>') ?></p>
				<p><?php _e('The absolute path to the folder containing the WebHelp collection you want to embed, including a trailing slash. It can be on the same server as your WordPress installation or on a different server. Always use the full absolute path for this, including the http:// or https:// prefix, even if your WebHelp is on the same server as your WordPress Example: "<i>http://myserver.com/help/</i>."','webhelp-plugin>') ?></p>
				<p style="font-weight: 600; font-size: 1rem; margin-top: 1rem;"><?php _e('Allowed Domains','webhelp-plugin>') ?></p>
				<p><?php _e('Domains of your WordPress and all your WebHelp sites if your WordPress and WebHelp are on different domains. Enter all the domains, separated by commas and including the http:// or https:// prefix but <b>without</b> a trailing slash. This must <b>also</b> be configured in the skin for your WebHelp, in the <b>EMBEDDED_DOMAINS</b> variable in the <b>General Settings</b> variables group. 
				<p><b>Example:</b></p><p><i>http://mydomain.com, http://www.anotherdomain.net, https://thirddomain.edu</i>.</p><p><strong>IMPORTANT:</strong> Only configure this if your WordPress and WebHelp are on different domains. Otherwise leave it empty.</p>','webhelp-plugin>') ?></p>
				<p style="font-weight: 600; font-size: 1rem; margin-top: 1rem;"><?php _e('Default State','webhelp-plugin>') ?></p>
				<p><?php _e('Whether the WebHelp is visible or hidden when WordPress is open. Normally, it should always be hidden, because it covers Wordpress content when it is open. Page loading is also faster when it is hidden.','webhelp-plugin>') ?></p>
				<p style="font-weight: 600; font-size: 1rem; margin-top: 1rem;"><?php _e('Default Topic','webhelp-plugin>') ?></p>
				<p><?php _e('The topic to be opened automatically when the user opens the WebHelp. If you want to open the WebHelp at the default topic this should normally be "index.html"','webhelp-plugin>') ?></p>
				
				<p style="font-weight: 600; font-size: 1rem; margin-top: 1rem;"><?php _e('Field-level Topic Link Text','webhelp-plugin>') ?></p>
				<p><?php _e('The text for the link bar at top of field-level topics. This link opens the displayed topic in a full help window. Default: "Click here to open this topic in a full help window"','webhelp-plugin>') ?></p>
				
				<p style="font-weight: 600; font-size: 1rem; margin-top: 1rem;"><?php _e('Button Texts','webhelp-plugin>') ?></p>
				<p><?php _e('The texts displayed initially in the Show/Hide Help button of the sidebar widget. These must be the same as the texts for this that you set in your skin, because the skin texts are used when the buttons switch.','webhelp-plugin>') ?></p>
				<p style="font-weight: 600; font-size: 1rem; margin-top: 1rem;"><?php _e('Position','webhelp-plugin>') ?></p>
				<p><?php _e('Choosing the position for the WebHelp window automatically disables the settings that must not be active. The other settings are set to example values that you should use as models.','webhelp-plugin>') ?></p>
				</td>
			</tr>
        </table>

        <?php  
		echo "<script>
		var hmState = document.getElementById('webhelp_position_input'),
			hmActive = document.getElementById('webhelp_active_input'),
			submitButton = document.getElementById('submit');
		hmState.onchange = function(){
			submitButton.click();
		}
		hmActive.onchange = function(){
			submitButton.click();
		}
		</script>"
		?>
    </form>
</div>